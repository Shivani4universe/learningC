## Learn C the Hard Way
- **https://www.oreilly.com/library/view/learn-c-the/9780134434452/**
