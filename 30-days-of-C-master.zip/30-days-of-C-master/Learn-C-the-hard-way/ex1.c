#include <stdio.h>
/* what is int
 what is main
 what is argc
 what is *argv[]
 */

int main(argc, *argv[])
{
    //what is ;
    int distance = 100;

    /*what is printf
    what is %d
    what is \n
    what is " "
    */

    printf("you are %d miles away from your destination\n");

    /* what is return
    what is 0
    */
    return 0;
}
