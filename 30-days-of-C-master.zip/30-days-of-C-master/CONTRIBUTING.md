## How to create a PR?

* Fork this repository 

* Add your name to the `CONTRIBUTORS.md` file according to the format given below:
- Name: [YOUR NAME](GitHub link)
- Place: City, State, Country
- About: Write a little about yourself
- GitHub: [GitHub account name](GitHub link)

* Create a pull request from your forked repository
* Your PR will soon be merged!
