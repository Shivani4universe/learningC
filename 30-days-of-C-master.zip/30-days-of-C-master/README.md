# 30-days-of-C 

- To celebrate Hacktoberfest (https://hacktoberfestguam.com/) I will be writing and learning C programs.
- This repository will remain active till 31st October.
**Join me in this adventure!**
**Lets learn together.**
- **https://coder-shivani.github.io/30-days-of-C/**
- **Update Oct 9: I successfully completed Hacktoberfest 2019!!**
- **Update Oct 10: I will also be writing blog-posts from now on to continue learning C. I will commit here only if I write some nice code till Oct 31st. I will continue writing about similar topics on my blog: https://technoshivani.wordpress.com/**
