/* Author: Shivani Mishra
Date: 2019-10-2
Description:
Prints the words "Hello, World" on the screen */


#include <stdio.h>
int main() {

printf("Hello, World\n");
return 0;

}
