# Resources
- To learn the core components of C language, start reading tutorials and write your own
test codes in a compiler. For a beginners introduction to C I have used following websites and tutorials
- **https://www.w3schools.in/c-tutorial/**
- **http://learn.onlinegdb.com/c_for_beginners**
