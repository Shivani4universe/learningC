/* Author: Shivani Mishra
Date: 2019.10.02
Description:
Control Flow - if else statements
*/

#include <stdio.h>
 main() {

     int i;

     scanf("%d", &i);
     if (1==1)
        {
            for(i=0; i<=10; i++)
            {
            printf("%d\n", i);
        }
    }

    else
    {
        printf("Please wait\n");
    }

    return 0;
}
