/* Author: Shivani Mishra
Date: 2019.10.3
Description:
sizeof() operator examples
*/

#include <stdio.h>
void main() {
   //operators

   printf("Storage size of int = %d\n", sizeof(int)); \\4
   printf("Storage size of float = %d\n", sizeof(float)); \\4
   printf("Storage size of double = %d\n", sizeof(double)); \\8
   printf("Storage size of char = %d\n", sizeof(char)); \\1

   return;

}
