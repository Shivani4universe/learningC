/* Author: Shivani Mishra
Date: 2019.10.4
Description:
An example of while loop that prints Infinite loop infinite times
*/

//while loop
#include <stdio.h>
int main() 
{
   int i = 1;
   while (i>0)
      {
         printf("Infinite loop\n");
      }
      return 0;
}
