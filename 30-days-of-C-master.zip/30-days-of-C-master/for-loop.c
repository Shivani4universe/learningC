/* Author: Shivani Mishra
Date: 2019.10.4
Description:
An example of for loop that prints Infinite loop
*/

//for loop
#include <stdio.h>
int main()
{
    int i;
    for(i=0; i>=0; i++)
       {
          printf("Infinite loop\n");
       }
       return 0;
}
